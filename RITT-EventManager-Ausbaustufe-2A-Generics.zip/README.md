# PoSeUebung-022
## Event Manager

<div align="center">
  <span><img src="/img/event-manager-conapp.png" alt="ConApp" width=30%><img src="/img/release.png" alt="ConApp-Release" width=30%></span>

  <img src="/img/generic-entityset.png" alt="generic Entity Set" width=90%>
</div>
