﻿global using System;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;
global using System.Collections.Generic;

global using EventManager.Common.Contracts;
global using Microsoft.Extensions.Configuration;
global using System.Net.WebSockets;




///   N A M E S P A C E   ///
namespace EventManager.Common;
