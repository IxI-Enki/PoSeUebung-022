﻿
///   N A M E S P A C E   ///
namespace EventManager.Common.Contracts;


public interface IIdentifiable
{
      #region ___P R O P E R T Y___ 
      int Id { get; protected set; }   
      #endregion
}